package com.example.smartparc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_parking.*
import android.content.Intent

class parking : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_parking)

        spaces.setOnClickListener{
            val intent = Intent(this, parkingslots::class.java)
            startActivity(intent)
        }
    }
}
